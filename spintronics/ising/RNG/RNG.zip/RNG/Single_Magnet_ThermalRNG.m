%%% Writen by Tianqi Gao (2016/12/09)%%%
% Single_Magnet_ThermalRNG ���ܵ���һ������������������ļ�;
% RNG_VCMA_Step_1 �ǵ�һ�׶�����Ŵ��VCMAЧӦ���¸�PMAʹ�Ż�ǿ�ȷ�������ƽ���ڵĺ����ļ�;
% RNG_Random_Step_2 �ǵڶ��׶η���VCMAЧӦ��ǿ��������ͬʱ��������������ʹ�Ż�ǿ�ȷ����������ĳ����ĺ����ļ�;
% RNG_statistic ��Ϊ����֤����ͳ�ƺ�����Ƿ�������50%;
% ����ȥ�� function output = statistic(i) ע�Ͳ�ȥ����ͼ����ʹ��;
% function output = statistic(i)
global gamma J_H_conv alpha H_VCMA Hext Hk Ms...
    H_bias kB T mu0 tau_c Hth

%%% LLG parameters %%%%%%%%%%%%%%%%%%%%%%%
%%% Constants
%%%------------
q=1.6e-19; % Coulombs
hbar=6.626e-34/2/pi; % Reduced Planck's constant (J-s) 
alpha = 0.02; %0.01 Gilbert damping parameter
g = 1.76e7*4*pi/1000; %1.76e7 Gyromagnetic ratio [(rad)/(Oe.s)]
mu0=1.2566e-6;%
T=300;
kB=1.38e-23;

%%% Magnet Parameters (taken from experiment) 
%%%-------------------------------------------
Ms = 1.2e6; % A/m, Saturation Magnetization [emu/cm^3] emu/cm^3 = 1 KA/m
V = (50*50*1)*1e-27; % Volume [m^3]
Ku2 = 66240; % Uni. anisotropy constant [J/m^3]
Hk = 2*Ku2/mu0/Ms; % Switching field [A/m]

%%%%%%%%%%%%%     VCMA[MKS]    %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%72.864%%%%%%%%%%%%%%%%%%%%%%%%%%%%
P=0.1;
Vs=1.4545;%0.4894��Voltage across the MTJ,[V]
ksi=11*72.864e-15;%VCMA constant [J/V.m];37e-10[erg/V.cm]
t_fl=1e-9;%thickness of freelayer
gamma=g/(1+alpha^2);% reduced factor
d_MgO=1.6e-9;% thickness of MgO barrier[m]
J_H_conv = hbar*P/(Hk*mu0*q*t_fl*Ms);
H_VCMA=2*ksi*Vs/(mu0*Ms*d_MgO*t_fl); %*mz,[Oe]
Hext=0; % external field 
H_bias=0; % bias magnetic field
mp=[0 0 1]; % pinned layer
theta0=sqrt(kB*T/mu0/Ms/Hk/V); % initial angle

%%% Initial conditions of the simulation
mz = cos(theta0); % Magnet slightly off easy axis 
m = [0 sqrt(1-mz^2) mz]; 

%%%%%%%   Step_1: Put the magnetization into plane   %%%%%%%
tau_c = 2*alpha*gamma*Hk; % LLG time constant
time1 = 2.5; % step_1 duration
tot1 = time1/1e-3; 
m_pre=[];
Time_pre=[];
for i=1:1:tot1

%discription of thermal noise   
r=0+1.*randn(1,3); % Normal distribution, expectation = 0, standard deviation = 1
delta_t=1e-12; % time step
Vol=50*50*1*1e-27; % Volume [m^3]
Hth=0*(sqrt(2*kB*T*alpha/(mu0*Ms*gamma*Vol*delta_t)))*r; % thermal noise field

options = odeset('RelTol',1e-8,'AbsTol',1e-9);
[t0,m1]=ode113('RNG_VCMA_Step_1',[0 0.001*1e-9*tau_c],m,options);

m_pre=[m_pre;m1];
Time_pre=[Time_pre;(t0+(i-1))];
m = m1(end,:);
end

%%%%%%%% Step_2: Generating random number %%%%%%%%%
m_roll=m_pre(end,:);
time2=2.5;% Step_2 duration
tot2=time2/1e-3;
m_eva=[];
Time_roll=[];
for i=1:1:tot2

r=0+1.*randn(1,3);
delta_t=1e-12;%time step
Vol=50*50*1*1e-27;%[m^3]
Hth=(sqrt(2*kB*T*alpha/(mu0*Ms*gamma*Vol*delta_t)))*r;

options = odeset('RelTol',1e-8,'AbsTol',1e-9);
[t,x]= ode113('RNG_Random_Step_2',[0 0.001*1e-9*tau_c], m_roll,options);

m_eva=[m_eva;x];
Time_roll=[Time_roll;(t+(i-1))];
m_roll = x(end,:);
end

T_eva=Time_pre(end,:)+Time_roll;
T_tot=[Time_pre;T_eva];
Mz=[m_pre;m_eva];

tau=T_tot/1000;
output=Mz(end,3);

figure(1)
hold on 
plot(tau,Mz(:,1),'k-','linewidth',3.0); % m_x 
plot(tau,Mz(:,2),'b-','linewidth',3.0); % m_y 
h = plot(tau,Mz(:,3),'r-','linewidth',3.0); % m_z
%axis([0 2.5 -1 1])
set(h,'linewidth',3.0) 
set(gca,'Fontsize',30)
xlabel('count')
toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%